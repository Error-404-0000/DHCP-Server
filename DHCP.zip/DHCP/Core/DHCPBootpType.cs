﻿public enum DHCPBootpType
{
    Request = 1,
    Reply = 2
}