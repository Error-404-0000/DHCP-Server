﻿using DHCP.Core;
using Lid;

Console.WriteLine("[LINI] ---DHCP SERVER 2025--- \n\n");
DHCP.Core.DHCPCore dhcp = new DHCP.Core.DHCPCore();
string input ;
Setter<DHCPCore> set = new Setter<DHCPCore>(dhcp);
do
{
    Console.Write("DHCP #> ");
    input = Console.ReadLine() ?? "";
    try
    {
        set.Execute(input);
    }
    catch (Exception ex)
    { 
        Console.WriteLine(ex.Message);
    }
}
while ((input ) != "exit");
